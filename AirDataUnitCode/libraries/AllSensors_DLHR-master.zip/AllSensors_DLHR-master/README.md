# Arduino library for AllSensors DLHR Series Low Voltage Digital Pressure Sensors #

This is an Arduino-compatible library for the [AllSensors DLHR Series Low Voltage Digital Pressure Sensors](https://www.allsensors.com/products/dlhr-series). The library currently supports I²C communications with the sensors.