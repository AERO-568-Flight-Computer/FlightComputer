# What Are these Files?

The .sch and .brd files hare are Eagle CAD schematic and PCB design files for the MPL3115A2 Breakout.

These files were created with Eagle 6.2.0. There is a free, lite, version of Eagle available from [cadsoftusa.com](cadsoftusa.com).

[Creative Commons Attribution-ShareAlike](http://creativecommons.org/licenses/by-sa/3.0/)
